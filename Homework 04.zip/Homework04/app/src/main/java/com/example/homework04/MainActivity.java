//Homework 4
//Homework04
//Eduardo Gomez, Elvis Velasquez

package com.example.homework04;

import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements AddDrinkFragment.drinkMade, SetProfileFragment.profileListener, BACCalculatorFragment.resetApp, ViewDrinksFragment.drinks_main_communicator {

    public static ArrayList<Drink> drinks = new ArrayList<>();



    Profile currentProfile;

    public static boolean  drinksCheck(){

        return drinks.isEmpty();

    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        getSupportFragmentManager().beginTransaction()
                //MainFragmnet is the BAC MAin screen
                //.add( R.id.mainContainer, mainFrag, "MainFragment")
                .add(R.id.mainContainer, new BACCalculatorFragment(), "MainFragment")
                .commit();
    }

    @Override
    public void addDrinkToArray(Drink drink) {
        drinks.add(drink);

        BACCalculatorFragment temp= (BACCalculatorFragment) getSupportFragmentManager().findFragmentByTag("MainFragment");
        if(temp!=null){

            temp.drinksChange(drinks);
        }
        getSupportFragmentManager().popBackStack();
    }

    @Override
    public void profileInfo(Profile p) {
        currentProfile = p;
        BACCalculatorFragment temp= (BACCalculatorFragment) getSupportFragmentManager().findFragmentByTag("MainFragment");
        if(temp!=null){

            temp.update(currentProfile);

        }
        drinks.clear();
    }


    @Override
    public void reset() {
        drinks.clear();

    }

    @Override
    public void launchSet(String s) {

        switch (s){
            case "setProfileFrag":
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.mainContainer, new SetProfileFragment(), "setProfileFrag")
                        .addToBackStack(null)
                        .commit();

                break;
            case "viewDrinksFragment":
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.mainContainer, new ViewDrinksFragment(), "viewDrinksFragment")
                        .addToBackStack(null)
                        .commit();
                break;

            case "addDrinksFragment":
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.mainContainer, new AddDrinkFragment(), "addDrinksFragment")
                        .addToBackStack(null)
                        .commit();
                break;
        }

    }

    @Override
    public void drinksFromMain() {
        ViewDrinksFragment temp= (ViewDrinksFragment) getSupportFragmentManager().findFragmentByTag("viewDrinksFragment");

        if (temp!= null ){
            // pass this drinks list to ViewDrinksFragment drinks list
            temp.passDrinks(drinks);
        }
    }

    @Override
    public void drinksToMain(ArrayList<Drink> drinkList) {
        // pass drinkList from ViewDrinkFragment
        drinks = drinkList;
    }
}