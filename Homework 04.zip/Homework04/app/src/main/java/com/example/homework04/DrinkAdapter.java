package com.example.homework04;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class DrinkAdapter extends RecyclerView.Adapter<DrinkAdapter.DrinkView> {
    ArrayList<Drink> Drinks;

    public DrinkAdapter(ArrayList<Drink> info){
        this.Drinks = info;
    }

    @NonNull
    @Override
    public DrinkView onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.info_adapter, parent, false);
        DrinkView drinkView = new DrinkView(view);


        return drinkView;
    }

    @Override
    public void onBindViewHolder(@NonNull DrinkView holder, int position) {
        Drink currentDrink = Drinks.get(position);

        holder.alcoholAmount.setText(currentDrink.getAlcoholContent());
        holder.oz.setText(currentDrink.getDrinkSizeOz());
        holder.date.setText(currentDrink.getDateTime());

    }

    @Override
    public int getItemCount() {
        return this.Drinks.size();
    }

    public static class DrinkView extends RecyclerView.ViewHolder {
        TextView alcoholAmount;
        TextView oz;
        TextView date;

    public DrinkView(@NonNull View itemView) {
        super(itemView);
        alcoholAmount = itemView.findViewById(R.id.textViewAdapterAlcoholAmount);
        oz = itemView.findViewById(R.id.textViewAdapterOzAmount);
        date = itemView.findViewById(R.id.dateTime2);
    }
}
/*
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if(convertView == null){
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.info_adapter, parent, false);

        }

        TextView alcoholAmount = convertView.findViewById(R.id.textViewAdapterAlcoholAmount);
        TextView oz = convertView.findViewById(R.id.textViewAdapterOzAmount);
        TextView date = convertView.findViewById(R.id.dateTime2);

        Drink currentDrink = getItem(position);

        alcoholAmount.setText(currentDrink.getAlcoholContent());
        oz.setText(currentDrink.getDrinkSizeOz());
        date.setText(currentDrink.getDateTime());

        return super.getView(position, convertView, parent);
    }

 */
}
