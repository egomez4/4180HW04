package com.example.homework04;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link SetProfileFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class SetProfileFragment extends Fragment {

    int weight = 0;
    String gender = "";

    public void checkVaildNumber(EditText number){
        //check input to see if it is a valid number if not display toast
        try{
            weight = Integer.parseInt(number.getText().toString());
        }catch (Exception e){
            Toast.makeText(getActivity(), "Please enter a positive number", Toast.LENGTH_SHORT).show();
        }

        if(weight < 0){
            Toast.makeText(getActivity(), "Please enter a positive number", Toast.LENGTH_SHORT).show();
        }
    }

    public boolean inputCheckerOne(Integer num, RadioGroup radio){
        if(num <= 0){
            Toast.makeText(getActivity(), "Please enter a positive number", Toast.LENGTH_SHORT).show();

            return false;
        }

        if(radio.getCheckedRadioButtonId() == -1){
            Toast.makeText(getActivity(), "Please select a gender", Toast.LENGTH_SHORT).show();
            return false;
        }else if(radio.getCheckedRadioButtonId() == R.id.radioButtonFemale){
            gender = "(Female)";

        }else if(radio.getCheckedRadioButtonId() == R.id.radioButtonMale){
            gender = "(Male)";
        }

        return true;
    }

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public SetProfileFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment SetProfileFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static SetProfileFragment newInstance(String param1, String param2) {
        SetProfileFragment fragment = new SetProfileFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_set_profile, container, false);

        //Buttons
        Button setButton = view.findViewById(R.id.weightButton);
        Button cancelButton = view.findViewById(R.id.buttonCancel);

        //text
        EditText weightEntered = view.findViewById(R.id.enterWeight);

        //radio groups and buttons
        RadioGroup genderButton = view.findViewById(R.id.radioGroupGender);
        RadioButton female = view.findViewById(R.id.radioButtonFemale);

        setButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkVaildNumber(weightEntered);


                //Inputchecker will set wieght and gender for us to send back if all if good
                if(inputCheckerOne(weight, genderButton)) {

                    weightEntered.getText().clear();
                    female.setChecked(true);
                    com.example.homework04.Profile p = new com.example.homework04.Profile(weight, gender);
                    current.profileInfo(p);
                    getActivity().getSupportFragmentManager().popBackStack();


                }
            }
        });

        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getActivity().getSupportFragmentManager().popBackStack();
            }
        });

        // Inflate the layout for this fragment
        return view;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);

        if(context instanceof  profileListener){
            current = (profileListener) context;
        }
    }

    profileListener current;

    public interface profileListener{
        public void profileInfo(com.example.homework04.Profile p);
    }
}