package com.example.homework04;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class ViewDrinksRecyclerViewAdapter extends RecyclerView.Adapter<ViewDrinksRecyclerViewAdapter.ViewDrinksViewHolder>{

    ArrayList<Drink> drinks;
    OnTrashClickListener trashListener;

    public ViewDrinksRecyclerViewAdapter(ArrayList<Drink> drinksList){
        this.drinks = drinksList;
    }

    @NonNull
    @Override
    public ViewDrinksViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate((R.layout.drinks_view_item), parent, false);
        ViewDrinksViewHolder viewDrinksViewHolder = new ViewDrinksViewHolder(view);

        return viewDrinksViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewDrinksViewHolder holder, int position) {
        Drink drink = drinks.get(position);
        holder.drinksItemAlcohol.setText("%" + drink.getAlcoholContent() + " Alcohol");
        holder.drinksItemDate.setText("Date Added: " + drink.getDateTime());
        holder.oz.setText(drink.getDrinkSizeOz() + " Oz");
        holder.trash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drinks.remove(drink);
                notifyItemRemoved(holder.getAdapterPosition());
                notifyItemRangeChanged(holder.getAdapterPosition(),drinks.size());
            }
        });

    }

    @Override
    public int getItemCount() {
        return this.drinks.size();
    }

    public static class ViewDrinksViewHolder extends RecyclerView.ViewHolder{
        TextView drinksItemAlcohol;
        TextView drinksItemDate;
        ImageButton trash;
        TextView oz;


        public ViewDrinksViewHolder(@NonNull View itemView) {
            super(itemView);
            drinksItemAlcohol = itemView.findViewById(R.id.drinksItemAlcohol);
            drinksItemDate = itemView.findViewById(R.id.drinksItemDate);
            trash = itemView.findViewById(R.id.trash);
            oz = itemView.findViewById(R.id.drinkOz);

        }
    }

    public ArrayList<Drink> getDrinks(){
        return drinks;
    }


    /* interface to communicate with main activity
     */
    public interface OnTrashClickListener{
        void deleteDrink(Drink drink);
    }

}
