package com.example.homework04;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link ViewDrinksFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ViewDrinksFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM3 = "param1";
    int drinkIndex = 0;
    ViewDrinksRecyclerViewAdapter adapter;


    // TODO: Rename and change types of parameters
    private ArrayList<Drink> drinks;

    public ViewDrinksFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param dr
     * @return A new instance of fragment ViewDrinksFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static ViewDrinksFragment newInstance(ArrayList<Drink> dr) {
        ViewDrinksFragment fragment = new ViewDrinksFragment();
        Bundle args = new Bundle();
        args.putParcelableArrayList(ARG_PARAM3, dr);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            drinks = getArguments().getParcelableArrayList(ARG_PARAM3);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.new_view_drinks, container, false);

        // get drinks from the main activity
        d.drinksFromMain();

        TextView sortByAlcohol = view.findViewById(R.id.textViewByAlcohol);
        TextView sortByDate = view.findViewById(R.id.textViewSortByDate);

        Button ascendingAlcohol = view.findViewById(R.id.alcoholAsc);
        Button descendingAlcohol = view.findViewById(R.id.alcoholDesc);
        Button ascendingDate = view.findViewById(R.id.dateAsc);
        Button descendingDate = view.findViewById(R.id.dateDesc);
        Button close = view.findViewById(R.id.buttonNewViewDrinksCancel);

        RecyclerView drinksRecycler = view.findViewById(R.id.recycler);

        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        drinksRecycler.setLayoutManager(layoutManager);
        drinksRecycler.setHasFixedSize(true);

        adapter = new ViewDrinksRecyclerViewAdapter(drinks);
        drinksRecycler.setAdapter(adapter);



        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                d.drinksToMain(drinks);

                getActivity().getSupportFragmentManager().popBackStack();
            }
        });

        ascendingAlcohol.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // sort array by alcohol content asending
                Collections.sort(drinks, Comparator.comparing(Drink::getAlcoholContent));
                adapter.notifyDataSetChanged();
            }
        });

        descendingAlcohol.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Collections.sort(drinks, Comparator.comparing(Drink::getAlcoholContent));
                Collections.reverse(drinks);
                adapter.notifyDataSetChanged();
            }
        });

        ascendingDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Collections.sort(drinks, Comparator.comparing(Drink::getDateTime));
                adapter.notifyDataSetChanged();
            }
        });

        descendingDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Collections.sort(drinks, Comparator.comparing(Drink::getDateTime));
                Collections.reverse(drinks);
                adapter.notifyDataSetChanged();
            }
        });

        return view;

    }

    @Override
    public void onResume() {
        super.onResume();
        //drinks = adapter.getDrinks();
    }

    public void passDrinks(ArrayList<Drink> drinksList){
        // set drinks field to drinks from main activity
        drinks = drinksList;
    }


    drinks_main_communicator d;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if(context instanceof drinks_main_communicator){
            d = (drinks_main_communicator) context;
        }
    }

    // used to communicate with main activity and get or send data
    public interface drinks_main_communicator{

        void drinksFromMain();
        void drinksToMain(ArrayList<Drink> drinkList);
    }
}