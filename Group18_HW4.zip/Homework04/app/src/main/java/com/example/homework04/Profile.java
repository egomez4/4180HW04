package com.example.homework04;

public class Profile {

    int wieght;
    String gender;

    public Profile(int wieght, String gender) {
        this.wieght = wieght;
        this.gender = gender;
    }

    public int getWieght() {
        return wieght;
    }

    public String getGender() {
        return gender;
    }


}
