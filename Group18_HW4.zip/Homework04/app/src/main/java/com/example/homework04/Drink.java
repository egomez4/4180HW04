package com.example.homework04;


import android.os.Parcel;
import android.os.Parcelable;


public class Drink implements Parcelable {

    // Fields
    int alcoholContent;
    int drinkSizeOz;
    String dateTime;

    public Drink(int alcoholContent, int drinkSizeOz, String dateTime) {
        this.alcoholContent = alcoholContent;
        this.drinkSizeOz = drinkSizeOz;
        this.dateTime = dateTime;
    }

    protected Drink(Parcel in) {
        drinkSizeOz = in.readInt();
        alcoholContent = in.readInt();
        dateTime = in.readString();

    }

    public static final Creator<Drink> CREATOR = new Creator<Drink>() {
        @Override
        public Drink createFromParcel(Parcel in) {
            return new Drink(in);
        }

        @Override
        public Drink[] newArray(int size) {
            return new Drink[size];
        }
    };

    public int getAlcoholContent() {
        return alcoholContent;
    }

    public int getDrinkSizeOz() {
        return drinkSizeOz;
    }

    public void setAlcoholContent(int alcoholContent) {
        this.alcoholContent = alcoholContent;
    }

    public void setDrinkSizeOz(int drinkSizeOz) {
        this.drinkSizeOz = drinkSizeOz;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(drinkSizeOz);
        parcel.writeInt(alcoholContent);
        parcel.writeString(dateTime);

    }

    public String getDateTime() {
        return dateTime;
    }

    public void setDateTime(String dateTime) {
        this.dateTime = dateTime;
    }
}
